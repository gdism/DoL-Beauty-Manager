/* UI only writes manager-owned state; imported files remain immutable. */
(() => {
'use strict';
const sessions=new WeakMap();
function state(api){if(!sessions.has(api))sessions.set(api,{sources:[],rows:[],imports:api.importedSources||[],summary:null,selected:api.savedSelection?.()||'current',fingerprint:null,controller:null});return sessions.get(api);}
function el(tag,text,attrs={}){const e=document.createElement(tag);if(text!==undefined)e.textContent=text;for(const[k,v]of Object.entries(attrs))e.setAttribute(k,v);return e;}
function download(bytes,name,mime){const u=URL.createObjectURL(new Blob([bytes],{type:mime}));const a=el('a',undefined,{href:u,download:name});document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),30000);}
function render(api,s){
 const d=s.dialog;if(!d)return;if(s.baseline&&d.querySelector('[data-baseline-status]'))d.querySelector('[data-baseline-status]').textContent='已校验原版基线：'+s.baseline.id+'，'+s.baseline.files.size+'张图片。';d.querySelector('[data-status]').textContent=s.message||'选择扫描已加载来源，或导入 img 文件夹 / ZIP。';
 const select=d.querySelector('select');select.replaceChildren(el('option','当前启用组合',{value:'current'}));for(const src of s.sources)select.append(el('option',src.name+'（'+src.assets.size+' 项）',{value:src.sourceId}));select.value=s.selected;
 const body=d.querySelector('tbody');body.replaceChildren();for(const src of s.sources){const a=[...src.assets.values()];const tr=el('tr');for(const value of [src.name,a.length,a.filter(a=>a.declared).length,a.filter(a=>a.registered).length,a.filter(a=>a.enabled).length,a.filter(a=>a.readState==='readable').length])tr.append(el('td',String(value)));body.append(tr);}
 const failures=s.sources.flatMap(src=>[...src.assets.values()].filter(a=>a.error).map(a=>a.logicalPath+'：'+a.error)).concat(s.sources.flatMap(src=>src.issues.map(i=>src.name+'：'+i.code+' '+(i.reason||''))));const conflicts=s.rows.filter(r=>r.status==='resolver-conflict'||r.status==='observation-failed');
 d.querySelector('[data-details]').textContent=JSON.stringify({目标版本:s.profile,扫描:s.summary,修复结果:s.prepared?.report,检测:s.diagnostics,解析冲突:conflicts,读取问题:failures,验证范围:'来源字节和注册关系；布局、遮罩、状态与Android尚未全面验收',应用:api.inspect().status},null,2);
 d.querySelector('[data-action=apply]').textContent=s.prepared?.incomplete?'应用已验证独立组':'应用完整所选组合';
 for(const b of d.querySelectorAll('button[data-action]'))b.disabled=!!s.controller&&b.dataset.action!=='cancel';
}
async function busy(api,s,fn){if(s.controller)throw Error('已有操作进行中');s.controller=new AbortController();render(api,s);try{await fn(s.controller.signal);}catch(e){s.message=e.name==='AbortError'?'操作已取消，当前应用保持不变。':'未完成：'+e.message;}finally{s.controller=null;render(api,s);}}
function reference(s){return DBMConfig.baselines.find(b=>b.cleanSourceVerified&&b.targetProfileHash===s.profile?.rendererProfileHash);}
function diagnose(s){const ref=reference(s);return DBMDiagnostics.analyze(s.sources,s.rows,{profile:s.profile,stateCatalog:s.stateCatalog,targetAssets:ref?Object.fromEntries(ref.assetMetadata.map(a=>[a.path,a])):{},baselineVerified:!!ref,layers:DBMDiagnostics.activeLayers(window.Renderer)});}
function inputManifest(c){return c.assets.map(a=>({path:a.path,sha256:a.sha256,sourceId:a.sourceId}));}
async function metadata(s,c){const input=s.prepared?.inputManifest||inputManifest(c),byPath=new Map(input.map(a=>[a.path,a]));const provenance=new Map(input.map(a=>[a.path,[a]]));
 for(const report of s.prepared?.report||[])for(const g of report.groups||[]){if(g.status==='committed')for(const p of g.evidence?.paths||[])provenance.set(p.dst,byPath.has(p.src)?[byPath.get(p.src)]:[{path:p.src,sha256:p.sha256,sourceId:'verified-rule-source'}]);
  if(g.status==='fallback-original')for(const path of g.paths||g.fallbackPaths||[])provenance.set(path,[{path,sha256:s.baseline?.verifiedHashes[path],sourceId:g.baselineId}]);}
 const sourceMap=[];for(const a of c.assets)sourceMap.push({path:a.path,outputHash:await DBMEngine.hash(a.bytes),sources:provenance.get(a.path)||[],derived:!byPath.has(a.path)||byPath.get(a.path).sha256!==await DBMEngine.hash(a.bytes)});
 return {scope:s.prepared?.incomplete?'verified independent groups only':'complete selected image composition',incomplete:!!s.prepared?.incomplete,sourceSnapshotHash:await DBMEngine.hash(JSON.stringify([...input].sort((a,b)=>a.path.localeCompare(b.path,'en')))),selection:s.selected,repairReport:s.prepared?.report||null,targetProfile:s.profile,sourceMap,inputManifest:input,issues:s.prepared?.issues||[],verification:['source bytes and resolution checked'],unverified:['all rendering states','Android']};}
async function scan(api,s,signal){
 s.prepared=null;s.profile=await DBMProfiles.match();s.stateCatalog=await DBMProfiles.stateCatalog(s.profile);if(!s.baseline&&s.profile.status==='matched')try{s.baseline=await DBMBaseline.restore(s.profile,{signal});}catch(e){s.baselineCacheError=String(e);}s.message='读取已加载的来源…';render(api,s);s.sources=[...await DBMSources.host(api.hostContext()),...s.imports];
 s.summary=await DBMSources.scan(s.sources,{signal,onProgress:p=>{s.message='扫描 '+p.done+' / '+p.total+'：'+p.path;if(p.done%16===0)render(api,s);}});
 const managed=api.isManaged();s.rows=await DBMSources.resolve(s.sources,{signal,observe:async p=>{if(!managed&&api.hostContext().hook?.getImage){const u=await api.hostContext().hook.getImage(p);return u?DBMSources.fromURL(u):undefined;}return api.readUpstream(p);}});
 s.diagnostics=diagnose(s);s.fingerprint=await api.fingerprint();s.message='扫描完成：'+s.summary.readable+' 项可读取，'+s.summary.failed+' 项失败。'+(managed?'已按修复前上游链读取，排除了管理器输出。':'已对照宿主实际取图结果。');
}
function composition(s,{allowPartial=false,allowEmpty=false}={}){if(!s.summary)throw Error('请先扫描');const c=DBMSources.compose(s.sources,s.rows,{sourceId:s.selected==='current'?undefined:s.selected});if(c.issues.length&&(!allowPartial||c.issues.some(i=>i.code==='non-image-dependencies')))throw Error('组合存在 '+c.issues.length+' 项阻塞，详见报告；未应用不完整结果');if(!c.assets.length&&!allowEmpty)throw Error('所选组合没有可应用图片');return c;}
function dStatus(s){if(s.dialog)s.dialog.querySelector('[data-status]').textContent=s.message;}
function report(api,s){return {...DBMSources.report(s.sources,s.rows),summary:s.summary,targetProfile:s.profile,diagnostics:s.diagnostics,repair:s.prepared?.report||null,selection:s.selected,composition:s.summary?DBMSources.compose(s.sources,s.rows,{sourceId:s.selected==='current'?undefined:s.selected}).issues:[],runtime:api.inspect()};}
async function action(name,api,s,signal){
 if(name==='scan')return scan(api,s,signal);
 if(name==='apply'){
  if(s.fingerprint!==await api.fingerprint())throw Error('上游来源或顺序已变化，请重新扫描');const c=s.prepared?{assets:[...s.prepared.tree.files].map(([path,bytes])=>({path,bytes,sourceId:'managed-repair'}))}:composition(s);const r=await api.apply(c.assets,await metadata(s,c),{signal});s.message=r.status==='unchanged'?'所选结果已应用，无需重复提交。':s.prepared?.incomplete?(r.persisted?'已保存并应用通过验证的独立组；其他组保留上游，完整导出仍被阻止。':'独立组仅在本次会话应用，保存失败；完整导出仍被阻止。'):(r.persisted?'完整所选组合已应用并保存。':'本次会话已应用；持久化失败，请导出备份。');return;
 }
 if(name==='undo'){await api.undo();s.message='已恢复修复前组合；这不等同恢复原版素材。';return;}
 if(name==='export'){const b=await api.exportZip({signal,onProgress:p=>{if(p.phase==='zip'){s.message='生成完整 ZIP：'+Math.floor(p.percent)+'%';dStatus(s);}}});if(signal.aborted)throw new DOMException('取消','AbortError');download(b,'DoL美化组合.mod.zip','application/zip');s.message='完整组合 ZIP 已生成并交给浏览器下载。';return;}
 if(name==='report'){download(JSON.stringify(report(api,s),null,2),'DoL美化检测报告.json','application/json');s.message='检测报告已生成。';return;}
 if(name==='storage'){s.message=JSON.stringify(await api.storageInfo());return;}
 if(name==='clear'){await api.undo();await api.clearImports();await DBMBaseline.clear();s.baseline=null;s.imports=[];s.sources=[];s.rows=[];s.summary=null;s.message=api.status==='undone-storage-failed'?'本次会话已撤销，但保存结果清除失败，重载前请检查存储权限。':'已撤销应用并清除本管理器的保存结果和本次导入。';return;}
 if(name==='original'){
  s.prepared=null;
  const cancelled=()=>{if(signal.aborted)throw new DOMException('取消','AbortError');};
  if(!s.baseline?.cleanSourceVerified)throw Error('请先导入并验证原版基线');if(s.fingerprint!==await api.fingerprint())throw Error('上游已变化，请重新扫描');s.profile=await DBMProfiles.match();if(s.profile.rendererProfileHash!==s.baseline.targetProfileHash)throw Error('基线与当前宿主不匹配');const c=composition(s,{allowPartial:true,allowEmpty:true});let tree=new DBMEngine.Tree(c.assets.map(a=>[a.path,a.bytes]));const groups=[],covered=new Set(),issues=[...c.issues];
  const selectedPaths=new Set(s.sources.flatMap(src=>[...src.assets.values()].filter(a=>s.selected==='current'?a.enabled:src.sourceId===s.selected).map(a=>a.logicalPath)));
  for(const pack of DBMConfig.rulePacks){cancelled();if(pack.targetProfileHash!==s.profile.rendererProfileHash||!await DBMProfiles.checkContract(pack))continue;for(const g of pack.groups){cancelled();if(!g.fallbackPaths?.length||g.requiredOutputs.every(p=>covered.has(p)))continue;if(!g.requiredOutputs.some(p=>selectedPaths.has(p)))continue;const replacements=[],missing=[];for(const p of g.requiredOutputs){cancelled();const b=s.baseline.files.get(p);if(!b||await DBMEngine.hash(b)!==s.baseline.verifiedHashes[p])missing.push(p);else replacements.push([p,b]);}cancelled();if(missing.length){groups.push({id:g.id,status:'fallback-unavailable',missingBaseline:missing});issues.push({code:'baseline-group-unavailable',groupId:g.id,paths:missing});continue;}const work=tree.clone();for(const[p,b]of replacements)work.set(p,b);tree=work;for(const p of g.requiredOutputs)covered.add(p);groups.push({id:g.id,status:'fallback-original',baselineId:s.baseline.id,paths:g.requiredOutputs,evidence:g.evidence});}}
  cancelled();if(!covered.size)throw Error('所选来源没有可完整回退的已验证依赖组；请检查原版基线和检测报告');if(issues.length)tree=new DBMEngine.Tree([...tree.files].filter(([p])=>covered.has(p)));s.prepared={tree,inputManifest:inputManifest(c),issues,incomplete:!!issues.length,report:[{status:issues.length?'partial-original-groups-prepared':'original-groups-prepared',groups,unverified:['other groups and game states']}]};s.message='已准备 '+groups.filter(g=>g.status==='fallback-original').length+' 个完整依赖组的原版回退。'+(issues.length?'部分来源或基线组不可用；仅可应用已验证独立组，完整导出被阻止。':'点击应用完整所选组合后生效。');return;
 }
 if(name==='repair'){
  if(!s.summary)await scan(api,s,signal);if(s.fingerprint!==await api.fingerprint())throw Error('上游已变化，请重新扫描');
  s.profile=await DBMProfiles.match();if(s.profile.status!=='matched')throw Error('宿主渲染profile未确认，保留检测报告，不自动套用规则');
  if(!DBMConfig.rulePacks.some(pack=>pack.targetProfileHash===s.profile.rendererProfileHash))throw Error('当前版本没有匹配的已验证规则；旧规则不会被自动套用');
  const c=composition(s,{allowPartial:true});let tree=new DBMEngine.Tree(c.assets.map(a=>[a.path,a.bytes]));const reports=[];
  for(const pack of DBMConfig.rulePacks){if(pack.targetProfileHash!==s.profile.rendererProfileHash||!await DBMProfiles.checkContract(pack))continue;const result=await DBMRules.run(tree,pack,{engine:DBMEngine,codec:DBMEngine.pngCodec(DBMPNG.PNG),targetProfileHash:s.profile.rendererProfileHash,baseline:s.baseline,signal});tree=result.tree;reports.push(result.report);}
  if(!reports.length)throw Error('当前版本没有匹配的已验证规则；旧规则不会被自动套用');
  if(c.issues.length){const allowed=new Set();for(const report of reports){const pack=DBMConfig.rulePacks.find(p=>p.id===report.rulePackId);for(const row of report.groups)if(['committed','already-adapted','fallback-original'].includes(row.status))for(const path of pack.groups.find(g=>g.id===row.id).requiredOutputs)allowed.add(path);}if(!allowed.size)throw Error('没有可独立应用的完整验证组；读取问题仍在检测报告中');tree=new DBMEngine.Tree([...tree.files].filter(([p])=>allowed.has(p)));}
  s.prepared={tree,inputManifest:inputManifest(c),report:reports,issues:c.issues,incomplete:!!c.issues.length};const groups=reports.flatMap(r=>r.groups);s.message=(c.issues.length?'部分来源不可读或有冲突：仅准备已验证独立组，完整导出被阻止。':'')+'已准备修复结果：'+groups.filter(g=>g.status==='committed').length+' 组修复，'+groups.filter(g=>g.status==='already-adapted').length+' 组已适配。点击应用完整所选组合后生效；其他项目仍按报告标注。';return;
 }
}
function open(api){
 const s=state(api);let d=s.dialog;if(!d){
 d=el('dialog',undefined,{id:'dbm-panel','aria-labelledby':'dbm-title'});s.dialog=d;d.style.cssText='width:min(860px,92vw);max-width:92vw;max-height:88vh;overflow:auto;background:#171c26;color:#e8edf5;border:1px solid #64758c;border-radius:12px;padding:20px;font:15px/1.6 system-ui;box-sizing:border-box';
 const style=el('style');style.textContent='#dbm-panel button,#dbm-panel select{font:inherit;margin:4px;padding:7px 10px;max-width:100%;white-space:normal}#dbm-panel table{width:100%;border-collapse:collapse}#dbm-panel td,#dbm-panel th{text-align:left;border-bottom:1px solid #405065;padding:5px;overflow-wrap:anywhere}#dbm-panel pre{white-space:pre-wrap;overflow-wrap:anywhere}#dbm-panel::backdrop{background:#000a}';d.append(style);
 const close=el('button','关闭',{'aria-label':'关闭美化管理'});close.style.float='right';close.onclick=()=>d.close();d.append(close,el('h2','美化管理',{id:'dbm-title'}),el('p','导入文件保持原样。应用与撤销只管理本工具的覆盖层。'));
 const toolbar=el('div');for(const[name,label]of [['scan','扫描已加载来源'],['repair','检查并修复'],['original','按已验证组回退原版'],['apply','应用完整所选组合'],['undo','恢复修复前组合'],['export','导出完整 ZIP'],['report','下载检测报告'],['storage','查看存储'],['clear','清理本工具数据'],['cancel','取消当前操作']]){const b=el('button',label,{'data-action':name,type:'button'});b.onclick=()=>name==='cancel'?s.controller?.abort():busy(api,s,signal=>action(name,api,s,signal));toolbar.append(b);}d.append(toolbar);
 const imports=el('div');for(const[k,label]of [['zip','导入 img ZIP / 美化包'],['directory','导入 img 目录']]){const l=el('label',label+' '),input=el('input',undefined,{type:'file','aria-label':label});if(k==='directory'){input.setAttribute('webkitdirectory','');input.multiple=true;}else input.accept='.zip,.mod.zip,.zipmod';input.onchange=()=>busy(api,s,async signal=>{const files=[...input.files];if(!files.length)return;const added=k==='directory'?await DBMSources.importDirectory(files,{name:files[0].webkitRelativePath.split('/')[0]}):await DBMSources.importZip(new Uint8Array(await files[0].arrayBuffer()),{Zip:DBMZip,name:files[0].name});s.imports.push(...added);s.selected=added[0]?.sourceId||'current';await scan(api,s,signal);try{await api.saveImports(s.imports);}catch(e){s.message+=' 导入源未保存到离线缓存：'+e.message;}input.value='';});l.append(input);imports.append(l,el('br'));}d.append(imports);
 const baselineBox=el('fieldset');baselineBox.append(el('legend','原版基线'));
 const baselineStatus=el('p','只启用与官方固定提交清单逐项匹配的基线。',{'data-baseline-status':''});baselineBox.append(baselineStatus);
 const progress=p=>{s.message=p.phase==='download'?'下载基线：'+(p.bytes/1048576).toFixed(1)+' MiB':'基线'+p.phase+'：'+(p.done||0)+' / '+p.total;render(api,s);};
 const accept=async(source,signal)=>{s.profile=await DBMProfiles.match();s.baseline=await source(s.profile,{signal,onProgress:progress});const descriptor=DBMBaseline.descriptor(s.profile);s.diagnostics=diagnose(s);baselineStatus.textContent='已验证原版基线：'+s.baseline.id+'，'+s.baseline.files.size+' 个文件。';s.message=s.baseline.persisted===false?'原版基线本次会话校验通过；离线保存失败，可本次使用。':'原版基线校验并离线保存完成，可用于规则定义的整组回退。';};
 for(const[k,label]of [['zip','导入原版 ZIP'],['directory','导入原版 img 目录']]){const l=el('label',label+' '),input=el('input',undefined,{type:'file','aria-label':label});if(k==='directory'){input.setAttribute('webkitdirectory','');input.multiple=true;}else input.accept='.zip';input.onchange=()=>busy(api,s,async signal=>{const files=[...input.files];if(!files.length)return;await accept((profile,o)=>k==='zip'?files[0].arrayBuffer().then(b=>DBMBaseline.zip(new Uint8Array(b),profile,o)):DBMBaseline.directory(files,profile,o),signal);input.value='';});l.append(input);baselineBox.append(l,el('br'));}
 const net=el('button','从固定官方来源获取',{type:'button','data-action':'baseline-network'});net.onclick=()=>busy(api,s,signal=>accept(DBMBaseline.network,signal));baselineBox.append(net);
 for(const d of DBMConfig.baselines)baselineBox.append(el('a','下载官方 '+d.sourceCommit.slice(0,12)+' 源码 ZIP',{href:d.archiveUrl,target:'_blank',rel:'noopener noreferrer'}));d.append(baselineBox);

 const choose=el('label','应用 / 导出范围：'),select=el('select',undefined,{'aria-label':'来源选择'});select.onchange=()=>{s.selected=select.value;s.prepared=null;render(api,s);};choose.append(select);d.append(choose,el('p',undefined,{'data-status':'','aria-live':'polite'}));
 const table=el('table'),head=el('thead'),tr=el('tr');for(const x of ['来源','资产','声明','登记','启用','可读取'])tr.append(el('th',x));head.append(tr);table.append(head,el('tbody'));d.append(table);const details=el('details'),summary=el('summary','检测细节与未验收项');details.append(summary,el('pre',undefined,{'data-details':''}));d.append(details,el('p','自动修复仅覆盖已验证规则。其他人物状态与 Android 仍待验收，扫描通过不等于完整兼容。'));document.body.append(d);
 }
 render(api,s);if(!d.open)d.showModal();
}
window.DBMUI={open,state,scan,composition,report};
})();
